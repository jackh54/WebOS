import React from "react";
import Desktop from "./components/Desktop";
import "./App.css";

const App = () => {
  return <Desktop />;
};

export default App;
